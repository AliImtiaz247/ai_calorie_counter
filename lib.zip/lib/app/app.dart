import 'package:flutter/material.dart';
import '../features/splash/presentation/splash_screen.dart';
import 'theme.dart';

class AiCalorieCounterApp extends StatelessWidget {
  const AiCalorieCounterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'AI Calorie Counter',
      theme: AppTheme.lightTheme,
      home: const SplashScreen(),
    );
  }
}
