import 'package:ai_calorie_counter/features/scan/presentation/scan_food_screen.dart';
import 'package:flutter/material.dart';

import '../../../core/models/user_profile.dart';
import '../../../core/utils/health_calculator.dart';
import '../../../core/widgets/info_card.dart';

import '../../../core/widgets/meal_card.dart';
import '../../../core/widgets/quick_action_card.dart';
import '../../../core/widgets/section_title.dart';

import '../../meals/models/meal.dart';
import '../../meals/data/meal_repository.dart';
import '../../meals/presentation/add_meal_screen.dart';

class DashboardScreen extends StatefulWidget {
  final UserProfile profile;

  const DashboardScreen({super.key, required this.profile});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final MealRepository mealRepository = MealRepository();

  List<Meal> meals = [];

  bool mealsLoading = true;

  double totalCalories = 0;
  double totalProtein = 0;
  double totalCarbs = 0;
  double totalFat = 0;

  double breakfastCalories = 0;
  double lunchCalories = 0;
  double dinnerCalories = 0;
  double snacksCalories = 0;

  @override
  void initState() {
    super.initState();
    loadMeals();
  }

  Future<void> loadMeals() async {
    meals = await mealRepository.getTodaysMeals();

    totalCalories = 0;
    totalProtein = 0;
    totalCarbs = 0;
    totalFat = 0;

    breakfastCalories = 0;
    lunchCalories = 0;
    dinnerCalories = 0;
    snacksCalories = 0;

    for (final meal in meals) {
      totalCalories += meal.calories;
      totalProtein += meal.protein;
      totalCarbs += meal.carbs;
      totalFat += meal.fat;

      switch (meal.mealType) {
        case "Breakfast":
          breakfastCalories += meal.calories;
          break;

        case "Lunch":
          lunchCalories += meal.calories;
          break;

        case "Dinner":
          dinnerCalories += meal.calories;
          break;

        case "Snacks":
          snacksCalories += meal.calories;
          break;
      }
    }

    if (!mounted) return;

    setState(() {
      mealsLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (mealsLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final bmi = HealthCalculator.calculateBMI(
      weight: widget.profile.currentWeight,
      height: widget.profile.height,
    );

    final bmiStatus = HealthCalculator.bmiCategory(bmi);

    final bmr = HealthCalculator.calculateBMR(
      age: widget.profile.age,
      height: widget.profile.height,
      weight: widget.profile.currentWeight,
      gender: widget.profile.gender,
    );

    final dailyCalories = HealthCalculator.calculateDailyCalories(
      bmr: bmr,
      activity: widget.profile.activityLevel,
      goal: widget.profile.goal,
    );

    final progress = (totalCalories / dailyCalories).clamp(0.0, 1.0);

    return Scaffold(
      appBar: AppBar(
        title: const Text("AI Calorie Counter"),
        centerTitle: true,
      ),
      body: RefreshIndicator(
        onRefresh: loadMeals,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Welcome, ${widget.profile.name.isNotEmpty ? widget.profile.name : widget.profile.email.split('@').first} 👋",
                style: const TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 5),

              const Text(
                "Let's reach today's goal!",
                style: TextStyle(color: Colors.grey, fontSize: 16),
              ),

              const SizedBox(height: 20),

              InfoCard(
                child: Column(
                  children: [
                    ListTile(
                      leading: const Icon(Icons.local_fire_department),
                      title: const Text("Daily Calories"),
                      trailing: Text(
                        "$dailyCalories kcal",
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                      ),
                    ),

                    const Divider(),

                    ListTile(
                      leading: const Icon(Icons.monitor_weight),
                      title: const Text("Current Weight"),
                      trailing: Text("${widget.profile.currentWeight} kg"),
                    ),

                    ListTile(
                      leading: const Icon(Icons.track_changes),
                      title: const Text("Target Weight"),
                      trailing: Text("${widget.profile.targetWeight} kg"),
                    ),

                    ListTile(
                      leading: const Icon(Icons.favorite),
                      title: const Text("BMI"),
                      trailing: Text("${bmi.toStringAsFixed(1)} ($bmiStatus)"),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 25),
              InfoCard(
                child: Column(
                  children: [
                    const Text(
                      "Today's Calories",
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    const SizedBox(height: 20),

                    CircularProgressIndicator(value: progress, strokeWidth: 10),

                    const SizedBox(height: 20),

                    Text(
                      "${totalCalories.toStringAsFixed(0)} / $dailyCalories kcal",
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 25),

              InfoCard(
                child: Column(
                  children: [
                    const Text(
                      "Today's Nutrition",
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    const SizedBox(height: 20),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Column(
                          children: [
                            const Icon(Icons.fitness_center),
                            const SizedBox(height: 6),
                            const Text("Protein"),
                            Text("${totalProtein.toStringAsFixed(1)} g"),
                          ],
                        ),
                        Column(
                          children: [
                            const Icon(Icons.rice_bowl),
                            const SizedBox(height: 6),
                            const Text("Carbs"),
                            Text("${totalCarbs.toStringAsFixed(1)} g"),
                          ],
                        ),
                        Column(
                          children: [
                            const Icon(Icons.opacity),
                            const SizedBox(height: 6),
                            const Text("Fat"),
                            Text("${totalFat.toStringAsFixed(1)} g"),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 25),

              const SectionTitle(title: "Quick Actions"),

              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisSpacing: 15,
                mainAxisSpacing: 15,
                childAspectRatio: 1.3,
                children: [
                  QuickActionCard(
                    icon: Icons.camera_alt,
                    title: "Scan Food",
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const ScanFoodScreen(),
                        ),
                      );
                    },
                  ),

                  QuickActionCard(
                    icon: Icons.restaurant,
                    title: "Meals",
                    onTap: () {},
                  ),
                  QuickActionCard(
                    icon: Icons.water_drop,
                    title: "Water",
                    onTap: () {},
                  ),
                  QuickActionCard(
                    icon: Icons.monitor_weight,
                    title: "Weight",
                    onTap: () {},
                  ),
                ],
              ),

              const SizedBox(height: 25),

              const SectionTitle(title: "Today's Meals"),

              MealCard(
                mealName: "Breakfast",
                calories: "${breakfastCalories.toStringAsFixed(0)} kcal",
                icon: Icons.free_breakfast,
                onTap: () async {
                  final refresh = await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) =>
                          const AddMealScreen(mealType: "Breakfast"),
                    ),
                  );

                  if (refresh == true) {
                    loadMeals();
                  }
                },
              ),

              MealCard(
                mealName: "Lunch",
                calories: "${lunchCalories.toStringAsFixed(0)} kcal",
                icon: Icons.lunch_dining,
                onTap: () async {
                  final refresh = await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const AddMealScreen(mealType: "Lunch"),
                    ),
                  );

                  if (refresh == true) {
                    loadMeals();
                  }
                },
              ),

              MealCard(
                mealName: "Dinner",
                calories: "${dinnerCalories.toStringAsFixed(0)} kcal",
                icon: Icons.dinner_dining,
                onTap: () async {
                  final refresh = await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const AddMealScreen(mealType: "Dinner"),
                    ),
                  );

                  if (refresh == true) {
                    loadMeals();
                  }
                },
              ),

              MealCard(
                mealName: "Snacks",
                calories: "${snacksCalories.toStringAsFixed(0)} kcal",
                icon: Icons.apple,
                onTap: () async {
                  final refresh = await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const AddMealScreen(mealType: "Snacks"),
                    ),
                  );

                  if (refresh == true) {
                    loadMeals();
                  }
                },
              ),

              const SizedBox(height: 25),

              InfoCard(
                child: Column(
                  children: const [
                    Text(
                      "Water Intake",
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 15),
                    Text("💧□□□□□□□", style: TextStyle(fontSize: 30)),
                    SizedBox(height: 10),
                    Text("0 / 8 Glasses", style: TextStyle(fontSize: 18)),
                  ],
                ),
              ),

              const SizedBox(height: 25),

              InfoCard(
                child: Column(
                  children: [
                    const Text(
                      "Weight Goal",
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    const SizedBox(height: 15),

                    Text(
                      "Current: ${widget.profile.currentWeight} kg",
                      style: const TextStyle(fontSize: 18),
                    ),

                    const SizedBox(height: 10),

                    Text(
                      "Target: ${widget.profile.targetWeight} kg",
                      style: const TextStyle(fontSize: 18),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }
}
