import 'package:flutter/material.dart';
import '../../../core/models/ai_food_result.dart';
import 'package:firebase_auth/firebase_auth.dart';

// ignore: depend_on_referenced_packages
import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/meal.dart';
import '../data/meal_repository.dart';

class AddMealScreen extends StatefulWidget {
  final String mealType;
  final Meal? meal;
  final AIFoodResult? aiResult;

  const AddMealScreen({
    super.key,
    required this.mealType,
    this.meal,
    this.aiResult,
  });

  @override
  State<AddMealScreen> createState() => _AddMealScreenState();
}

class _AddMealScreenState extends State<AddMealScreen> {
  final foodController = TextEditingController();
  final caloriesController = TextEditingController();
  final proteinController = TextEditingController();
  final carbsController = TextEditingController();
  final fatController = TextEditingController();
  final quantityController = TextEditingController();

  final MealRepository mealRepository = MealRepository();

  bool isLoading = false;

  @override
  void dispose() {
    foodController.dispose();
    caloriesController.dispose();
    proteinController.dispose();
    carbsController.dispose();
    fatController.dispose();
    quantityController.dispose();
    super.dispose();
  }

  // ignore: strict_top_level_inference
  Future<void> saveMeal() async {
    if (foodController.text.isEmpty ||
        caloriesController.text.isEmpty ||
        proteinController.text.isEmpty ||
        carbsController.text.isEmpty ||
        fatController.text.isEmpty ||
        quantityController.text.isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("Please fill all fields")));
      return;
    }

    setState(() {
      isLoading = true;
    });

    try {
      final meal = Meal(
        id:
            widget.meal?.id ??
            FirebaseFirestore.instance.collection('temp').doc().id,
        userId: FirebaseAuth.instance.currentUser!.uid,
        mealType: widget.mealType,
        foodName: foodController.text.trim(),
        calories: double.parse(caloriesController.text),
        protein: double.parse(proteinController.text),
        carbs: double.parse(carbsController.text),
        fat: double.parse(fatController.text),
        quantity: double.parse(quantityController.text),
        createdAt: widget.meal?.createdAt ?? DateTime.now(),
      );

      if (widget.meal == null) {
        await mealRepository.addMeal(meal);
      } else {
        await mealRepository.updateMeal(meal);
      }
      if (!mounted) return;

      Navigator.pop(context, true);
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  Widget buildField(String label, TextEditingController controller) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 18),
      child: TextField(
        controller: controller,
        keyboardType: TextInputType.numberWithOptions(decimal: true),
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();

    if (widget.meal != null) {
      foodController.text = widget.meal!.foodName;
      caloriesController.text = widget.meal!.calories.toString();
      proteinController.text = widget.meal!.protein.toString();
      carbsController.text = widget.meal!.carbs.toString();
      fatController.text = widget.meal!.fat.toString();
      quantityController.text = widget.meal!.quantity.toString();
    }

    if (widget.aiResult != null) {
      debugPrint("========== AI RESULT RECEIVED ==========");
      debugPrint("Food: ${widget.aiResult!.foodName}");
      debugPrint("Calories: ${widget.aiResult!.calories}");
      debugPrint("Protein: ${widget.aiResult!.protein}");
      debugPrint("Carbs: ${widget.aiResult!.carbs}");
      debugPrint("Fat: ${widget.aiResult!.fat}");
      debugPrint("Fiber: ${widget.aiResult!.fiber}");
      debugPrint("Quantity: ${widget.aiResult!.quantity}");
      debugPrint("Healthy Score: ${widget.aiResult!.healthyScore}");
      debugPrint("=======================================");

      foodController.text = widget.aiResult!.foodName;
      caloriesController.text = widget.aiResult!.calories.toString();
      proteinController.text = widget.aiResult!.protein.toString();
      carbsController.text = widget.aiResult!.carbs.toString();
      fatController.text = widget.aiResult!.fat.toString();
      quantityController.text = widget.aiResult!.quantity.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.meal == null
              ? "Add ${widget.mealType}"
              : "Edit ${widget.mealType}",
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: ListView(
          children: [
            TextField(
              controller: foodController,
              decoration: const InputDecoration(
                labelText: "Food Name",
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 20),

            buildField("Calories", caloriesController),

            buildField("Protein (g)", proteinController),

            buildField("Carbs (g)", carbsController),

            buildField("Fat (g)", fatController),

            buildField("Quantity", quantityController),

            const SizedBox(height: 30),

            SizedBox(
              width: double.infinity,
              height: 55,
              child: ElevatedButton(
                onPressed: isLoading ? null : saveMeal,
                child: isLoading
                    ? const SizedBox(
                        width: 24,
                        height: 24,
                        child: CircularProgressIndicator(
                          color: Colors.white,
                          strokeWidth: 3,
                        ),
                      )
                    : Text(
                        widget.meal != null
                            ? "Edit ${widget.mealType}"
                            : widget.aiResult != null
                            ? "Confirm AI Meal"
                            : "Add ${widget.mealType}",
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
