import 'package:ai_calorie_counter/features/meals/presentation/add_meal_screen.dart';
import 'package:flutter/material.dart';
import '../data/meal_repository.dart';
import '../models/meal.dart';
import 'widgets/meal_tile.dart';

class MealsScreen extends StatefulWidget {
  const MealsScreen({super.key});

  @override
  State<MealsScreen> createState() => _MealsScreenState();
}

class _MealsScreenState extends State<MealsScreen> {
  final MealRepository repository = MealRepository();

  bool loading = true;

  List<Meal> meals = [];

  @override
  void initState() {
    super.initState();
    loadMeals();
  }

  Future<void> loadMeals() async {
    meals = await repository.getTodaysMeals();

    if (!mounted) return;

    setState(() {
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    if (meals.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text("Today's Meals")),
        body: const Center(
          child: Text("No meals added today", style: TextStyle(fontSize: 18)),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text("Today's Meals")),
      body: RefreshIndicator(
        onRefresh: loadMeals,
        child: ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: meals.length,
          itemBuilder: (context, index) {
            final meal = meals[index];

            return MealTile(
              meal: meal,
              onDelete: () async {
                await repository.deleteMeal(meal.id);
                loadMeals();
              },
              onEdit: () async {
                final updated = await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) =>
                        AddMealScreen(mealType: meal.mealType, meal: meal),
                  ),
                );

                if (updated == true) {
                  loadMeals();
                }
              },
            );
          },
        ),
      ),
    );
  }
}
