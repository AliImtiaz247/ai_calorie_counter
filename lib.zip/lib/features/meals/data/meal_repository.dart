import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../models/meal.dart';

class MealRepository {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  final String uid = FirebaseAuth.instance.currentUser!.uid;

  /// Save Meal
  Future<void> addMeal(Meal meal) async {
    await _firestore
        .collection("users")
        .doc(uid)
        .collection("meals")
        .doc(meal.id)
        .set(meal.toMap());
  }

  /// Get Today's Meals
  Future<List<Meal>> getTodaysMeals() async {
    final now = DateTime.now();

    final start = DateTime(now.year, now.month, now.day);

    final end = start.add(const Duration(days: 1));

    final snapshot = await _firestore
        .collection("users")
        .doc(uid)
        .collection("meals")
        .where("createdAt", isGreaterThanOrEqualTo: Timestamp.fromDate(start))
        .where("createdAt", isLessThan: Timestamp.fromDate(end))
        .orderBy("createdAt")
        .get();

    return snapshot.docs.map((doc) => Meal.fromMap(doc.data())).toList();
  }

  /// Delete Meal
  Future<void> deleteMeal(String mealId) async {
    await _firestore
        .collection("users")
        .doc(uid)
        .collection("meals")
        .doc(mealId)
        .delete();
  }

  /// Update Meal
  Future<void> updateMeal(Meal meal) async {
    await _firestore
        .collection("users")
        .doc(uid)
        .collection("meals")
        .doc(meal.id)
        .update(meal.toMap());
  }
}
