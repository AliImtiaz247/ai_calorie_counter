import 'dart:io';

import 'package:flutter/material.dart';

import '../../../core/services/food_ai_service.dart';
//import '../../meals/models/meal.dart';
import '../../meals/presentation/add_meal_screen.dart';
import '../../../core/models/ai_food_result.dart';
import 'package:image_picker/image_picker.dart';

class ScanFoodScreen extends StatefulWidget {
  const ScanFoodScreen({super.key});

  @override
  State<ScanFoodScreen> createState() => _ScanFoodScreenState();
}

class _ScanFoodScreenState extends State<ScanFoodScreen> {
  final picker = ImagePicker();
  final FoodAIService foodAIService = FoodAIService();

  File? image;

  bool loading = false;

  Future<void> pickImage() async {
    final picked = await picker.pickImage(
      source: ImageSource.camera,
      imageQuality: 85,
    );

    if (picked == null) return;

    setState(() {
      image = File(picked.path);
    });
  }

  Future<void> analyzeFood() async {
    if (image == null) return;

    setState(() {
      loading = true;
    });

    try {
      final result = await foodAIService.analyzeFood(image!);

      print("RAW RESULT:");
      print(result);

      if (!mounted) return;

      final aiResult = AIFoodResult.fromJson(result);
      print("===== PARSED MODEL =====");
      print("Food: ${aiResult.foodName}");
      print("Calories: ${aiResult.calories}");
      print("Protein: ${aiResult.protein}");
      print("Carbs: ${aiResult.carbs}");
      print("Fat: ${aiResult.fat}");
      print("Fiber: ${aiResult.fiber}");
      print("Quantity: ${aiResult.quantity}");
      print("Healthy Score: ${aiResult.healthyScore}");
      print("========================");

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) =>
              AddMealScreen(mealType: "Scanned Food", aiResult: aiResult),
        ),
      );
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) {
        setState(() {
          loading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Scan Food")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Expanded(
              child: image == null
                  ? Container(
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.grey),
                      ),
                      child: const Text(
                        "No image selected",
                        style: TextStyle(fontSize: 18),
                      ),
                    )
                  : ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: Image.file(
                        image!,
                        width: double.infinity,
                        fit: BoxFit.cover,
                      ),
                    ),
            ),

            const SizedBox(height: 20),

            SizedBox(
              width: double.infinity,
              height: 55,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.camera_alt),
                label: const Text("Take Picture"),
                onPressed: pickImage,
              ),
            ),

            const SizedBox(height: 15),

            SizedBox(
              width: double.infinity,
              height: 55,
              child: ElevatedButton(
                onPressed: loading ? null : analyzeFood,
                child: loading
                    ? const CircularProgressIndicator(color: Colors.white)
                    : const Text("Analyze Food"),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
