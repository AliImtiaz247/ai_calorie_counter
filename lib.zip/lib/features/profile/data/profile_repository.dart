import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../../core/models/user_profile.dart';

class ProfileRepository {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> saveProfile(UserProfile profile) async {
    await _firestore.collection('users').doc(profile.uid).set(profile.toMap());
  }

  Future<UserProfile?> getProfile() async {
    final uid = FirebaseAuth.instance.currentUser!.uid;

    final doc = await _firestore.collection('users').doc(uid).get();

    if (!doc.exists) return null;

    return UserProfile.fromMap(doc.data()!);
  }
}
