class UserProfile {
  final String name;
  final int age;
  final double height;
  final double weight;
  final double targetWeight;

  UserProfile({
    required this.name,
    required this.age,
    required this.height,
    required this.weight,
    required this.targetWeight,
  });
}
