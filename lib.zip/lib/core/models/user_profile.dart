class UserProfile {
  final String uid;
  final String name;
  final String email;
  final int age;
  final double height;
  final double currentWeight;
  final double targetWeight;
  final String gender;
  final String activityLevel;
  final String goal;

  UserProfile({
    required this.uid,
    required this.name,
    required this.email,
    required this.age,
    required this.height,
    required this.currentWeight,
    required this.targetWeight,
    required this.gender,
    required this.activityLevel,
    required this.goal,
  });

  Map<String, dynamic> toMap() {
    return {
      "uid": uid,
      "name": name,
      "email": email,
      "age": age,
      "height": height,
      "currentWeight": currentWeight,
      "targetWeight": targetWeight,
      "gender": gender,
      "activityLevel": activityLevel,
      "goal": goal,
      "createdAt": DateTime.now(),
    };
  }

  factory UserProfile.fromMap(Map<String, dynamic> map) {
    return UserProfile(
      uid: map["uid"] as String,
      name: map["name"] as String,
      email: map["email"] as String,
      age: map["age"] as int,
      height: (map["height"] as num).toDouble(),
      currentWeight: (map["currentWeight"] as num).toDouble(),
      targetWeight: (map["targetWeight"] as num).toDouble(),
      gender: map["gender"] as String,
      activityLevel: map["activityLevel"] as String,
      goal: map["goal"] as String,
    );
  }
}
