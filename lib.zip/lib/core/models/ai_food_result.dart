class AIFoodResult {
  final String foodName;

  final double calories;
  final double protein;
  final double carbs;
  final double fat;
  final double fiber;

  final double quantity;
  final double confidence;

  final String servingSize;

  final int healthyScore;

  AIFoodResult({
    required this.foodName,
    required this.calories,
    required this.protein,
    required this.carbs,
    required this.fat,
    required this.fiber,
    required this.quantity,
    required this.confidence,
    required this.servingSize,
    required this.healthyScore,
  });

  factory AIFoodResult.fromJson(Map<String, dynamic> json) {
    final food = (json["foods"] as List).first as Map<String, dynamic>;
    final totals = (json["totals"] as Map<String, dynamic>?) ?? {};

    double numToDouble(dynamic value) {
      if (value == null) return 0.0;
      if (value is num) return value.toDouble();
      return double.tryParse(value.toString()) ?? 0.0;
    }

    return AIFoodResult(
      foodName: food["name"] ?? "Unknown",

      calories: numToDouble(totals["calories"] ?? food["calories"]),
      protein: numToDouble(totals["protein"] ?? food["protein"]),
      carbs: numToDouble(totals["carbs"] ?? food["carbs"]),
      fat: numToDouble(totals["fat"] ?? food["fat"]),
      fiber: numToDouble(totals["fiber"] ?? food["fiber"]),

      quantity: numToDouble(food["estimatedWeight"]),

      confidence: numToDouble(food["confidence"]),

      servingSize: "${food["estimatedWeight"] ?? 0} g",

      healthyScore: (json["healthyScore"] as num?)?.toInt() ?? 0,
    );
  }
}
