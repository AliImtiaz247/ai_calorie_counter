import 'package:flutter/material.dart';

class MealCard extends StatelessWidget {
  final String mealName;
  final String calories;
  final IconData icon;
  final VoidCallback onTap;

  const MealCard({
    super.key,
    required this.mealName,
    required this.calories,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: const Color(0xFF22C55E),
          child: Icon(icon, color: Colors.white),
        ),
        title: Text(mealName),
        subtitle: Text(calories),
        trailing: const Icon(Icons.arrow_forward_ios, size: 18),
        onTap: onTap,
      ),
    );
  }
}
