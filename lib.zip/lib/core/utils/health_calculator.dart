class HealthCalculator {
  static double calculateBMI({required double weight, required double height}) {
    final h = height / 100;
    return weight / (h * h);
  }

  static String bmiCategory(double bmi) {
    if (bmi < 18.5) return "Underweight";
    if (bmi < 25) return "Normal";
    if (bmi < 30) return "Overweight";
    return "Obese";
  }

  static double calculateBMR({
    required int age,
    required double height,
    required double weight,
    required String gender,
  }) {
    if (gender == "Male") {
      return (10 * weight) + (6.25 * height) - (5 * age) + 5;
    } else {
      return (10 * weight) + (6.25 * height) - (5 * age) - 161;
    }
  }

  static double activityMultiplier(String activity) {
    switch (activity) {
      case "Sedentary":
        return 1.2;

      case "Lightly Active":
        return 1.375;

      case "Moderately Active":
        return 1.55;

      case "Very Active":
        return 1.725;

      default:
        return 1.2;
    }
  }

  static int calculateDailyCalories({
    required double bmr,
    required String activity,
    required String goal,
  }) {
    double calories = bmr * activityMultiplier(activity);

    switch (goal) {
      case "Lose Weight":
        calories -= 500;
        break;

      case "Gain Weight":
        calories += 300;
        break;

      case "Maintain Weight":
        break;
    }

    return calories.round();
  }
}
