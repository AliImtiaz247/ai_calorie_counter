class ApiService {
  /// Android Emulator
  // static const String baseUrl = "http://10.0.2.2:3000";

  /// Real Android Phone
  static const String baseUrl = "http://192.168.10.6:3000";
}
