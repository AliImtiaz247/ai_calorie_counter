import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

import 'api_service.dart';

class FoodAIService {
  Future<Map<String, dynamic>> analyzeFood(File image) async {
    print("Uploading image...");
    final request = http.MultipartRequest(
      "POST",
      Uri.parse("${ApiService.baseUrl}/api/analyze-food"),
    );

    request.files.add(await http.MultipartFile.fromPath("image", image.path));

    final response = await request.send();

    final body = await response.stream.bytesToString();

    print("Status Code: ${response.statusCode}");
    print("Response: $body");

    final json = jsonDecode(body);
    //if (response.statusCode == 200 && json["success"] == true) {
    //return json["data"];
    if (response.statusCode == 200 && json["success"] == true) {
      print("========== AI JSON ==========");
      print(json["data"]);
      print("=============================");

      return json["data"];
    }

    throw Exception(json["error"] ?? "Failed to analyze food");
  }
}
